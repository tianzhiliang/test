echo "Cleaning previous builds first.."
rm -rf dist
rm -rf build
rm -rf pca.egg-info
rm -rf __pycache__
rm -rf .pytest_cache
rm -rf .pylint.d
rm -rf pca/data/*.zip
rm -rf pca/data/*.csv
rm -rf pca/__pycache__
rm -rf *.js
rm -rf *.html
rm -rf *.css
rm -rf *.dot
rm -rf *.png
